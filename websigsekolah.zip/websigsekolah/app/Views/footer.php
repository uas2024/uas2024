</div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        // untuk menghilangkan pesan data berhasil disimpan,dll
        $('.alert').delay(2000).fadeOut('slow');
    });
</script>
</body>

</html>